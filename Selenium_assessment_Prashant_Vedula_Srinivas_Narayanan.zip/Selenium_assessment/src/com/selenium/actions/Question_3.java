package com.selenium.actions;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Question_3 {
	public WebDriver driver;
	public String Browser="chrome";
	@Test
	public void testcase1() throws Throwable{
		//To choose which browser we want to choose
		if(Browser.equalsIgnoreCase("chrome")){
			System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
			driver=new ChromeDriver(); //OpenBrowser
		}else if(Browser.equalsIgnoreCase("mozilla")){
			System.setProperty("webdriver.firefox.marionette", "geckodriver.exe");
			 driver=new FirefoxDriver();
		}else if(Browser.equalsIgnoreCase("ie")){
			System.setProperty("webdriver.ie.driver", "IEDriverServer.exe");
			 driver=new InternetExplorerDriver();
		}
		
		
		driver.get("https://www.msn.com/en-in/"); //open url
		
		
		driver.manage().window().maximize(); //maximize browser
		
		//To Click on Onenote
		driver.findElement(By.xpath("//h3[contains(text(),'OneNote')]")).click();
		
		//To store all windows in list windowshandles
		Set<String> windowHandles = driver.getWindowHandles();
		Iterator<String> iterator = windowHandles.iterator();
		
		String mwd = iterator.next();
		String tab1 = iterator.next();
		
		//To switch window to tab 1 
		driver.switchTo().window(tab1);
		// To write mobile number in the text block
		driver.findElement(By.xpath("//input[@id='i0116']")).sendKeys("8056257450");
		//close a tab
		Thread.sleep(3000);
		driver.close();
		//Click on skype on main page
		//switch to main window
		driver.switchTo().window(mwd);
		//click on skype window
		driver.findElement(By.xpath("//h3[contains(text(),'Skype')]")).click();
		driver.quit();
}
}
