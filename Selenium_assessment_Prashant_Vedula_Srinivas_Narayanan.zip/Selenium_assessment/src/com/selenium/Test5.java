package com.selenium;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Test5 {
	public WebDriver driver;
	public String Browser="chrome";
	@Test
	public void testcase1(){
		SoftAssert st=new SoftAssert();
		//To choose which browser we want
		if(Browser.equalsIgnoreCase("chrome")){
			System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
			driver=new ChromeDriver(); //OpenBrowser
		}else if(Browser.equalsIgnoreCase("mozilla")){
			System.setProperty("webdriver.firefox.marionette", "geckodriver.exe");
			 driver=new FirefoxDriver();
		}else if(Browser.equalsIgnoreCase("ie")){
			System.setProperty("webdriver.ie.driver", "IEDriverServer.exe");
			 driver=new InternetExplorerDriver();
		}
	
		driver.get("http://localhost:9000/login.do"); //open url
		driver.manage().window().maximize(); //maximize browser
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//username and password
		WebElement username = driver.findElement(By.xpath("//input[@name='username']"));
		username.sendKeys("admin");
		driver.findElement(By.xpath("//input[@name='pwd']")).sendKeys("manager");
		driver.findElement(By.xpath("//a[@id='loginButton']")).click();
		//Click on task
		driver.findElement(By.xpath("//a[@class='content tasks']//img[@class='sizer']")).click();
		//Click on project and customer
		driver.findElement(By.xpath("//a[contains(text(),'Projects & Customers')]")).click();
		//Click on create new Project
		driver.findElement(By.xpath("//body/div[@id='container']/form[@id='customersProjectsForm']/table[@class='mainContentPadding rightPadding']/tbody/tr/td/table/tbody/tr/td/table/tbody/tr/td/input[2]")).click();
		//To choose customer A
		driver.findElement(By.xpath("//select[@name='customerId']")).sendKeys("Customer A");
		//To enter project and enter discription
		driver.findElement(By.xpath("//input[@name='name']")).sendKeys("Project B");
		driver.findElement(By.xpath("//textarea[@name='description']")).sendKeys("Discription  B");
		//To click on radio button
		driver.findElement(By.xpath("//input[@id='add_tasks_action']")).click();
		//To click on create project
		driver.findElement(By.xpath("//input[@name='createProjectSubmit']")).click();
		
		//success message
		try{
			driver.findElement(By.xpath("//span[@class='successmsg']")).isDisplayed();
			//Logout
					driver.findElement(By.xpath(".//*[@id='logoutLink']")).click();
			}catch(Throwable t){
				st.fail("Sucess msg does not displayed...");
				//Logout
				driver.findElement(By.xpath("//a[@id='logoutLink']")).click();
				//cancel creation
				driver.findElement(By.xpath(".//*[@id='DiscardChangesButton']")).click();
			}
		//close browser
				driver.quit();
				st.assertAll();

		
		

}
	

}
