package com.dxc.pms.trainingDAO;

import java.util.List;

import com.dxc.pms.model.Training_model;

public interface TrainingDAO {
public List<Training_model> displayAll();
public void getOnebyOne();

}
