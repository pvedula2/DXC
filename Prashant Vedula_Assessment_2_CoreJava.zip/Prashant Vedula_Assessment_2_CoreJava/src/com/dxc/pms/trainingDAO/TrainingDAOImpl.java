package com.dxc.pms.trainingDAO;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.sql.*;

import com.dxc.pms.dbcon.DBConnection;
import com.dxc.pms.model.Training_model;


public class TrainingDAOImpl implements TrainingDAO {
	public static final String FETCH_ALL_DATA= "select* from trainings ";
	Connection connection=DBConnection.getConnection();

	@Override
	public List<Training_model> displayAll() {
		List<Training_model>allRecords=new ArrayList<Training_model>();
		
	
		ResultSet res;
		try {
			Statement stat = connection.createStatement();
			res = stat.executeQuery(FETCH_ALL_DATA);
			while(res.next()) {
				Training_model model=new Training_model();
				model.setEmployee_name(res.getString(2));
				model.setSapID(res.getInt(1));
				model.setStream(res.getString(3));
				model.setPercentage(res.getInt(4));
				allRecords.add(model);
		} 
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return allRecords;
	}
	

	@Override
	public void getOnebyOne() {
		try {
			Statement stat = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_UPDATABLE);
			Scanner sc=new Scanner(System.in);
			String percentage;
 
			ResultSet res = stat.executeQuery(FETCH_ALL_DATA);
			while(res.next()) {
				System.out.println(res.getInt(1));
				System.out.println(res.getString(2));
				System.out.println(res.getString(3));
				System.out.println("Enter percentage");
				percentage=sc.next();
				res.updateString(4,percentage);
				res.updateRow();
				
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	

	}

}
