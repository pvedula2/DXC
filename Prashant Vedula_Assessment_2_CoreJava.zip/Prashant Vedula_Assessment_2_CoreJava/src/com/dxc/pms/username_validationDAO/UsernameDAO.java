package com.dxc.pms.username_validationDAO;

public interface UsernameDAO {
public boolean validate(String username,String password);
}
