package com.dxc.pms.username_validationDAO;



import com.dxc.pms.dbcon.DBConnection;
import java.sql.*;

public class UsernameDAOImpl implements UsernameDAO {
	Connection conn = DBConnection.getConnection();
	public static final String FETCH_USER = "select* from user where username=? and password=?";

	@Override
	public boolean validate(String username, String password) {
		boolean valid = false;
		try {
			Statement stat = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			PreparedStatement preparedStatement = conn.prepareStatement(FETCH_USER);

			preparedStatement.setString(1, username);
			preparedStatement.setString(2, password);
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				valid = true;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		return valid;

	}

}
