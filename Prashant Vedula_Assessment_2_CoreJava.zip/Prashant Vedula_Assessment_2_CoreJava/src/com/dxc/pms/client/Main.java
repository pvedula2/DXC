package com.dxc.pms.client;

public class Main {
public static void main(String[] args) {
	UsernameApp app=new UsernameApp();
	app.display();
	
	
}



}
