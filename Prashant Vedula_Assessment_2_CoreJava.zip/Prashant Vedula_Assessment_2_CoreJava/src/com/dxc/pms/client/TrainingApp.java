package com.dxc.pms.client;

import java.util.ListIterator;
import java.util.Scanner;

import com.dxc.pms.model.Training_model;
import com.dxc.pms.trainingDAO.TrainingDAOImpl;

public class TrainingApp {
	int choice = 0;
	int productId;
	String productName;
	int quantityOnHand;
	int price;

	public void display() {
		System.out.println("M E N U ");
		System.out.println("1)	Display All Training Records ");
		System.out.println("2)	Display Records one by One and update the percentage ");
		System.out.println("3)	E X I T ");

		Scanner scanner = new Scanner(System.in);
		System.out.println("Please enter your choice : (1-3)");
		choice = scanner.nextInt();
		TrainingDAOImpl daoImpl=new TrainingDAOImpl();

		switch (choice) {
		case 1:
			
			ListIterator<Training_model> litr = null;
			 litr=daoImpl.displayAll().listIterator();
			 while(litr.hasNext()){
			       System.out.println(litr.next());
			    }			
			break;
		case 2:
			daoImpl.getOnebyOne();
			
			break;
		case 3:
			System.out.println("Thanks for using my app");
			System.exit(0);

		default:
			System.out.println(" Please enter (1-3)");
		}
	}
}
