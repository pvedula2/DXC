package com.dxc.pms.client;

import java.util.Scanner;

import com.dxc.pms.username_validationDAO.UsernameDAOImpl;

public class UsernameApp {
	public void display() {

		System.out.println("Please Enter username :");
		Scanner sc = new Scanner(System.in);

		String userName = sc.next();

		System.out.println("Please Enter password :");
		String password = sc.next();

		UsernameDAOImpl daoImpl = new UsernameDAOImpl();
		boolean valid =daoImpl.validate(userName,password);
		if(valid==true) {
			System.out.println("User successfully authenticated.");
			TrainingApp app=new TrainingApp();
			app.display();
			
			
		}
			else {
				System.out.println("User name cannot be authenticated");
			}
		}
		
	}


