package com.dxc.pms.model;

public class Training_model {
	private int sapID;
	private String employee_name;
	private String stream;
	private int percentage;
	public Training_model() {
		super();
		this.sapID = 0;
		this.employee_name = null;
		this.stream = null;
		this.percentage = 0;
	}
	public Training_model(int sapID, String employee_name, String stream, int percentage) {
		super();
		this.sapID = sapID;
		this.employee_name = employee_name;
		this.stream = stream;
		this.percentage = percentage;
	}
	public int getSapID() {
		return sapID;
	}
	public void setSapID(int sapID) {
		this.sapID = sapID;
	}
	public String getEmployee_name() {
		return employee_name;
	}
	public void setEmployee_name(String employee_name) {
		this.employee_name = employee_name;
	}
	public String getStream() {
		return stream;
	}
	public void setStream(String stream) {
		this.stream = stream;
	}
	public int getPercentage() {
		return percentage;
	}
	public void setPercentage(int percentage) {
		this.percentage = percentage;
	}
	@Override
	public String toString() {
		return "training_model [sapID=" + sapID + ", employee_name=" + employee_name + ", stream=" + stream
				+ ", percentage=" + percentage + "]";
	}
	
	
	
	
	
	
	

}
