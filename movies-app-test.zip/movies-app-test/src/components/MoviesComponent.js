import React, { Component } from 'react';
import MoviesSeevice from '../service/MoviesSeevice'
import MoviesListComponents from './MoviesListComponents';

class MoviesComponent extends Component {
    constructor(props){
        super(props)
        this.state=({
            movieId:this.props.match.params.movID,
            movieName:'',
            budget:'',
            directorName:''

        })
        

    }
    componentWillMount(){
        MoviesSeevice.getMovie(this.state.movieId).then(
            response=>{
                this.setState({
                    movieName:response.data.movieName,
                    budget:response.data.budget,
                    directorName:response.data.directorName
                })
            }
        )
        
    }
    render() {
        return (
            <div>
    <h3> movieId :{this.state.movieId}</h3>
                <h3> movieName :{this.state.movieName}</h3>
                <h3> budget :{this.state.budget}</h3>
                <h3> directorName :{this.state.directorName}</h3>
                
            </div>
        );
    }
}

export default MoviesComponent;
