import React, { Component } from 'react';
import MoviesSeevice from '../service/MoviesSeevice';

class MoviesListComponents extends Component {
    constructor(props){
        super(props);
        this.state=({
            movies:[],
            message:''
        })
        this.refreshProduct=this.refreshProduct.bind(this);
        this.deleteButtonClick=this.deleteButtonClick.bind(this);
    }
    refreshProduct(){
        MoviesSeevice.getAllMovies().then(
            response=>
            this.setState({movies:response.data})
        )


    }
    componentWillMount(){
        this.refreshProduct();
    }
    deleteButtonClick(productId){
        MoviesSeevice.deleteMovie(productId).then(
            response=>{
                
                this.setState({
                    
                    message:`Movie ID: ${productId} has been deleted successfully.`
                })
                 this.refreshProduct()
            }
        )
        
            

            
        


    }
    
    render() {
        {
            return (<div>
                <div className="container">
                    <h2>Movies App</h2>
            {this.state.message && <div className="alert alert-success">{this.state.message}</div>}
      <table className="table table-striped table-dark table-hover">
      <thead>
        <tr>
          <th>movieId</th>
          <th>movieName</th>
          <th>budget</th>
          <th>Director's Name</th>
          <th>Update Action</th>
          <th>Delete Action</th>
          
        </tr>
      </thead>
      <tbody>
          {
          this.state.movies.map(movie =>
        <tr key={movie.movieId}> 
            <td>{movie.movieId}</td>
          <td>{movie.movieName}</td>
          <td>{movie.budget}</td>
          <td>{movie.directorName}</td>
          <td><button className="btn btn-warning" onClick={()=>this.updateMovieClicked(movie.movieId)}>Update</button></td>
          <td><button className="btn btn-danger" onClick={()=>this.deleteButtonClick(movie.movieId)}>Delete</button></td>
          
        </tr>
          )
          }
      </tbody>
    </table>
                </div>
                </div>
            );
        }
    }
    }


export default MoviesListComponents;