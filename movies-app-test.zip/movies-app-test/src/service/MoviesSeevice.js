import React, { Component } from 'react';
import axios from 'axios';
const MOVIES_AP_URL="http://localhost:8002/movies"

class MoviesSeevice extends Component {
    getAllMovies(){
        return axios.get(`${MOVIES_AP_URL}`);
 
     }
     deleteMovie(movieId){
         return axios.delete(`${MOVIES_AP_URL}/${movieId}`);
 
     }
    getMovie(movieId){
         return axios.get(`${MOVIES_AP_URL}/${movieId}`);
 
     }
 
}

export default new MoviesSeevice;