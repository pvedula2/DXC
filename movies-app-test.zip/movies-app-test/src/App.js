import React, { Component } from 'react';
import MoviesListComponents from './components/MoviesListComponents';
import {Switch,Route} from 'react-router-dom'
import {BrowserRouter as Router} from 'react-router-dom'
import './App.css'
import MoviesComponent from './components/MoviesComponent';

class App extends Component {
  render() {
    return (
      <div>
        <Router>
          <Switch>
          <Route exact path='/' component={MoviesListComponents}/>
          <Route exact path='/movies' component={MoviesListComponents}/>
          <Route exact path='/movies/:movID' component={MoviesComponent}/>
          </Switch>
        </Router>
        
      </div>
    );
  }
}

export default App;