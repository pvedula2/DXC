import React, { Component } from 'react';
import '../Second.css'
import ProductService from '../service/ProductService';

class Dealer extends Component {
    constructor(props){
        super(props)
        this.state=({
            user:[],
            maintainace:[],
            dealerID:this.props.match.params.dealerID
        })
        this.refreshProduct=this.refreshProduct.bind(this);
        this.deleteMaintainance=this.deleteMaintainance.bind(this);
        this.addMaintainance=this.addMaintainance.bind(this);
    }
    addMaintainance(userID,dealerID){
      this.props.history.push(`/update_add/dealer/${userID}/${dealerID}`)


    }
    deleteMaintainance(userID,maintainID){
      ProductService.deleteMaintainace(userID,maintainID).then(
        response=>{
          this.refreshProduct()

        }
      )
    }
    componentWillMount(){
        
      this.refreshProduct();
    
  }
    refreshProduct(){
      ProductService.history(this.state.dealerID).then(
          response =>{
              
              this.setState({
                  user:response.data
              })
              // this.refreshProduct()
              console.log(this.state.user)
          }
          
          
      )
      
  }
    render() {
        return (
            <div>
               <div className="container">
            <h2>My Product app</h2>
        {this.state.message && <div className="alert alert-success">{this.state.message}</div>}
  <table className="table table-striped table-dark table-hover">
  <thead>
    <tr>
      <th>User Name</th>
      <th>User Email</th>
      <th>Contact Number</th>
      <th>Pin Code</th>
      <th>maintainace</th>
      
      
    </tr>
  </thead>
  <tbody>
      {
      this.state.user.map(user =>
    <tr key={user.userName}> 
        <td>{user.userName}</td>
        <td>{user.email}</td>
      <td>{user.contactNumber}</td>
      <td>{user.pinCode}</td>
      {<td>{user.maintainace.map(maintainace =><div>
    <td>vehicleName:{maintainace.vehicleName}</td>    
    <td>service:{maintainace.service}</td>
    <td>date: {maintainace.date}</td>
    <td>mileage: {maintainace.mileage}</td>
    <td><button className="btn btn-danger" onClick={()=>this.deleteMaintainance(user.userId,maintainace.maintainID)}>Delete</button></td>
    <td><button className="btn btn-success " onClick={()=>this.addMaintainance(user.userId,this.state.dealerID)}>ADD</button></td>
    
    </div>
      

      )}</td>}
     
      
      {/* <td><button className="btn btn-warning" onClick={()=>this.updateProductClicked(product.productId)}>Update</button></td>
      <td><button className="btn btn-danger" onClick={()=>this.deleteButtonClick(product.productId)}>Delete</button></td>
      <td><button className="btn btn-success " onClick={()=>this.giveRating(product.productId)}>Write review</button></td>
    */}
    
      
    </tr>
      )
      }
      
  </tbody>
  
</table>




            </div>
            </div>
        );
    }
}

export default Dealer;