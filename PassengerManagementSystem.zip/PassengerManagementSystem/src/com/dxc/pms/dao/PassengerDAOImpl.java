package com.dxc.pms.dao;

import java.util.List;

import com.dxc.pms.model.Passenger;

public class PassengerDAOImpl implements PassengerDAO {

	public PassengerDAOImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public Passenger getPassengerInfo(int pnrNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addPassenger(Passenger passenger) {
		// TODO Auto-generated method stub

	}

	@Override
	public void removePassenger(int pnrNo) {
		// TODO Auto-generated method stub

	}

	@Override
	public void UpdatePassenger(Passenger passenger) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<Passenger> getAllPassengers() {
		// TODO Auto-generated method stub
		return null;
	}

}
