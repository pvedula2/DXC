import React, { Component } from 'react';
import { Formik, Field,Form, ErrorMessage } from 'formik';
import ProductService from '../service/ProductService';

class sendEmail extends Component {
    constructor(props){
        super(props)
        this.state=({
            userID:this.props.match.params.uid,
            message:'',
            carName: '',
            emergency:''

        })
        this.onSubmit= this.onSubmit.bind(this)
        this.validateForm=this.validateForm.bind(this)
    }
    onSubmit(values){
        console.log(values)
        console.log(this.state.userID)
        ProductService.sendEmail(this.state.userID,values.emergency,values.carName).then(
            response=>{
                alert("Successfully Sent")
            }
        )

            
       
    }
    validateForm(values){
        let errors = {}
    if(!values.carName){
        errors.carName = 'please enter car name'
    }
    else if(!values.emergency){
        errors.emergency = 'please enter your emergency'
    }
        console.log(errors)
        return errors;
}


    render() {
        
            let { carName,emergency } = this.state
            return (
               <div className="container">
                   <h1>Welcome to emergency page</h1>
    
                   <div class = "col-md-4" align="center">
                     
                      <Formik
                       initialValues={{carName,emergency}}
                      enableReinitialize = "true"
                      validateOnChange={false}
                      validateOnBlur={false}
                      validate ={this.validateForm}
                      onSubmit={this.onSubmit}
                      >
                          <Form>
    
                          <ErrorMessage name="carName" component="div"
                            className = "alert alert-warning"></ErrorMessage>
                           <ErrorMessage name="emergency" component="div"
                            className = "alert alert-warning"></ErrorMessage>
    
                          <fieldset className="form-group">
                                  <label>Car Name</label>
                                     <Field className="form-control"  type="text" name="carName" placeholder="enter your car name"></Field>
                          </fieldset>
                          <fieldset className="form-group">
                                  <label>Emergency</label>
                                     <Field className="form-control"  type="text" name="emergency" placeholder="please enter your emergency here"></Field>
                          </fieldset>
                          
    
                          <div>
                              <button className="btn btn-success" id="button" type="submit">Send</button>
                            </div>
                          </Form>
                      </Formik>
               </div>
               </div>
        );
    }
}

export default sendEmail;
