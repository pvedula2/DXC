import React, { Component } from 'react';
import { Formik, Field,Form, ErrorMessage } from 'formik';
import ProductService from '../service/ProductService';
import './add_update_maintainance.css'
import { SocialIcon } from 'react-social-icons';
import logo from './logo.jpg'

class sendEmail extends Component {
    constructor(props){
        super(props)
        this.state=({
            userID:this.props.match.params.uid,
            message:'',
            carName: '',
            emergency:''

        })
        this.onSubmit= this.onSubmit.bind(this)
        this.validateForm=this.validateForm.bind(this)
    }
    onSubmit(values){
        console.log(values)
        console.log(this.state.userID)
        ProductService.sendEmail(this.state.userID,values.emergency,values.carName).then(
            response=>{
                alert("Successfully Sent")
            }
        )

            
       
    }
    validateForm(values){
        let errors = {}
    if(!values.carName){
        errors.carName = 'please enter car name'
    }
    else if(!values.emergency){
        errors.emergency = 'please enter your emergency'
    }
        console.log(errors)
        return errors;
}


    render() {
        
            let { carName,emergency } = this.state
            return (
                <div className="u1">
                <header className="header">
                <nav className="navbar navbar-style">
                <div className="container" id="c1">
                        <div className="navbar-header">
                           <img src={logo} class="logo1" alt="not found"></img> 
                        </div>{
                         <h1 id="h1">Vehicle Maintenance App</h1>} 
                        <div className= "nav ">
                            <a href ="https://www.google.com/">home</a>
                            <a href ="">contact</a>
                            <a href ="">about us</a>
                            <a href ="">check</a>
                        </div>
                   </div>
                </nav>
            </header>
           
               <div className="container" id="a2">
                   <h2 id="h2">Welcome to emergency page</h2>
    
                   
                     
                      <Formik
                       initialValues={{carName,emergency}}
                      enableReinitialize = "true"
                      validateOnChange={false}
                      validateOnBlur={false}
                      validate ={this.validateForm}
                      onSubmit={this.onSubmit}
                      >
                          <Form>
                          <div className= "col-md-6"  id ="div10" >
                              <div>
                                  <h2 id="h2">Add</h2>
                          <ErrorMessage name="carName" component="div"
                            className = "alert alert-warning"></ErrorMessage>
                           <ErrorMessage name="emergency" component="div"
                            className = "alert alert-warning"></ErrorMessage>
    
                          <fieldset className="form-group">
                                  <label>Car Name</label>
                                     <Field className="form-control"  type="text" name="carName" placeholder="Enter your car name"></Field>
                          </fieldset>
                          <fieldset className="form-group">
                                  <label>Emergency</label>
                                     <Field className="form-control"  type="text" name="emergency" placeholder="Please enter your emergency here"></Field>
                          </fieldset>
                          <div>
                              <button className="btn btn-success" id="button" type="submit">Send</button>
                            </div>
                            </div>
                            </div>
                          </Form>
                          
                      </Formik>
               </div>
               <footer className="footer">
            &copy; Copyright: <a href="">Vehicle Maintenance</a>
                <div className = "footer-icons">
                <SocialIcon url="https://www.facebook.com/"  />
                <SocialIcon url="https://www.instagram.com/?hl=en"  />
                <SocialIcon url="https://twitter.com/login"  />
                <SocialIcon url="https://www.whatsapp.com/"  />
             
                </div>
            </footer>
               </div>
        );
    }
}

export default sendEmail;
