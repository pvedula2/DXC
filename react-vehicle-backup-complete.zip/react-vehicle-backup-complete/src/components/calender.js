import React, { Component } from 'react';

class calender extends Component {
    render() {
        return (
            <div>
                <h2>Inside Schedule Maintainance</h2>
                
            </div>
        );
    }
}

export default calender;