import React, { Component } from 'react';
import { Formik, Form,Field,ErrorMessage } from 'formik';
import '../App.css'
import ProductService from '../service/ProductService';

class loginUser extends Component {
    constructor(props){
        super(props)
    
        this.state = ({
            userName: '',
            email:'',
            password:'',
            contactNumber:'',
            pinCode:'',
            signUp:'',
            value:'option',
            userId:'',
            dealer:null,
            maintainace:[]
        })
        this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleChange(event) {
    console.log("Inside handleChange")
    this.setState({value: event.target.value});
    console.log("Inside Handle Change the value is "+this.state.value)
    
  }

  handleSubmit(event) {
      console.log("Inside handle submit")
      console.log(event)
      ProductService.addUser(event).then(
          response=>{
            this.props.history.push(`/login`)
          }
      )
  
  }
  


    validateForm(values){
      let errors={}
      ProductService.validateUser(values.userId).then(
        response=>{
          console.log(response.status)
          if(response.status==200){
            localStorage.setItem("userID",200)
          }
          else if(response.status==204)
          {
            console.log("else part")
            localStorage.setItem("userID",204)
          }
          
        }
      )
      
      
      if(200==localStorage.getItem("userID")){
          errors.userId="Please Enter unique user ID"
      }
      
      else if(!values.userId){
        errors.userId="Please enter user ID"
      }
      
      else if(!values.userName){
          errors.userName = 'please enter name'
      }

      else if(!values.email){
          errors.email='please enter email'
      }
      else if(!values.password){
          errors.password='please enter password'
      }
      else if(!values.contactNumber){
          errors.contactNumber='please enter your phone number'
      }
      else if(!values.pinCode){
          errors.pinCode='please enter pincode'
      }
      // else if(!values.signUp){
      //     errors.signUp='please select any one'
      // }
      else if(values.password.length<6){
          errors.password="password should not be less than 6"
      }
      console.log(errors)
      return errors
    }
    render() {
        let { userName, email, password, contactNumber, pinCode,maintainace,userId,dealer } = this.state
      return (
        <div className="container"> 
          <h1>App</h1>
         
              <div class = "col-md-4">
                 
                  <Formik
                   initialValues={{ userName, email, password, contactNumber, pinCode,userId,maintainace,dealer }}
                  enableReinitialize = "true"
                  validateOnChange={true}
                  validateOnBlur={false}
                  validate ={this.validateForm}
                  onSubmit={this.handleSubmit}
                  
                  >
                   
                      <Form>
                        <h2>Vehicle App</h2>
                      <ErrorMessage name="userName" component="div"
                        className = "alert alert-warning"></ErrorMessage>
                        <ErrorMessage name="userId" component="div"
                        className = "alert alert-warning"></ErrorMessage>

                        <ErrorMessage name="email" component="div"
                        className = "alert alert-warning"></ErrorMessage>
                        <ErrorMessage name="password" component="div"
                        className = "alert alert-warning"></ErrorMessage>
                        <ErrorMessage name="contactNumber" component="div"
                        className = "alert alert-warning"></ErrorMessage>
                        <ErrorMessage name="pinCode" component="div"
                        className = "alert alert-warning"></ErrorMessage>
                        <ErrorMessage name="signUp" component="div"
                        className = "alert alert-warning"></ErrorMessage>
                        
                    


                      <fieldset className="form-group">
                              <label>User ID</label>
                                 <Field className="form-control"  type="text" name="userId" placeholder="enter your User ID"></Field>
                      </fieldset>
                      <fieldset className="form-group">
                              <label>Name</label>
                                 <Field className="form-control"  type="text" name="userName" placeholder="enter your name"></Field>
                      </fieldset>
                          <fieldset className="form-group">
                              <label>Email</label>
                              <Field className="form-control" type="email" name="email"placeholder="enter your email"></Field>
                          </fieldset>
                          <fieldset className="form-group">
                              <label>Password </label>
                              <Field className="form-control" type="password" name="password" placeholder="enter your password"></Field>
                          </fieldset>
                          <fieldset className="form-group">
                              <label> Confirm Password </label>
                              <Field className="form-control" type="password" name="confirmPassword" placeholder="enter your password again"></Field>
                          </fieldset>
                          <fieldset className="form-group">
                              <label>Mobile Number</label>
                              <Field className="form-control" type="text" name="contactNumber" placeholder="enter your mobile number"></Field>
                          </fieldset>
                          <fieldset className="form-group">
                              <label>Pincode</label>
                              <Field className="form-control" type="text" name="pinCode" placeholder = "enter pincode"></Field>
                          </fieldset>
                          
         
                        <div>
                          <button value={this.state.value} className="btn btn-success" type="submit">Sign up</button>
                        </div> 
                      </Form>
                  </Formik>
                </div>
              </div>
      );
}
}

export default loginUser;