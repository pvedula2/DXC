var express = require("express")
var app = express();
var fs = require('fs')

app.set('view engine', 'ejs');

app.get("/", function (request, response) {


    var readStream = fs.readFileSync(__dirname + '/resources/about.txt', 'utf8');


    console.log(readStream);
    response.render("about", {

        data: readStream,

    });
})




console.log("Server started on port : 5001")
app.listen(5002);