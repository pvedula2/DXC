package com.dxc.pms.service;


	import java.util.*;
	import javax.mail.*;
	import javax.mail.internet.*;
	import javax.mail.*;
	import javax.mail.internet.InternetAddress;
	import javax.mail.internet.MimeMessage;

	import com.dxc.pms.model.Maintainance;

	public class SendEmailTLS {
		
	    public void sendEmail(String subject,List<Maintainance> body,String CarName )
	    {
	    	System.out.println("Inside sendEmail");
	        final String username = "poovizhisabapathi491@gmail.com";
	        final String password = "Poovizhi98";

	        Properties prop = new Properties();
			prop.put("mail.smtp.host", "smtp.gmail.com");
	        prop.put("mail.smtp.port", "587");
	        prop.put("mail.smtp.auth", "true");
	        prop.put("mail.smtp.starttls.enable", "true"); //TLS
	        
	        Session session = Session.getInstance(prop,
	                new javax.mail.Authenticator() {
	                    protected PasswordAuthentication getPasswordAuthentication() {
	                        return new PasswordAuthentication(username, password);
	                    }
	                });

	        try {

	            Message message = new MimeMessage(session);
	            message.setFrom(new InternetAddress("poovizhisabapathi491@gmail.com"));
	            message.setRecipients(
	                    Message.RecipientType.TO,
	                    InternetAddress.parse("poovizhi1155@gmail.com")
	            );
	            message.setSubject(subject);
	            message.setText("Dear Dealer,"
	                    + CarName+"\n\n "+body);

	            Transport.send(message);

	            System.out.println("Done");

	        } catch (MessagingException e) {
	            e.printStackTrace();
	        }
	    }



	}


