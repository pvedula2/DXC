package com.dxc.pms.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.dxc.pms.model.Dealer;
import com.dxc.pms.model.Maintainance;
import com.dxc.pms.model.User;
import com.dxc.pms.service.DealerService;
import com.dxc.pms.service.UserService;
import com.mongodb.WriteResult;


@Repository
public class DealerDAOImpl implements DealerDAO {

	@Autowired
	UserService userService;
    DealerService dealerService;
	@Autowired
	MongoTemplate mongotemplate;
	DealerDAO dealerDAO;
	@Autowired
	UserDaoImpl daoImpl;
	
	@Override
	public boolean addDealer(int userId,Dealer dealer) {
		// TODO Auto-generated method stub
		User user=userService.getUser(userId);
		System.out.println(user);
		user.setDealer(dealer);
		mongotemplate.save(user);
		mongotemplate.save(user.getDealer(),"dealer");
		return false;
	}
	
	@Override
	public Dealer getDealer(int userId,int dealerId) {
		User user=userService.getUser(userId);
		System.out.println(user);
		Dealer r= user.getDealer();
		System.out.println(r);
			if(r.getDealerId()==dealerId) {
				return r;
			}
		return null;
	}
	 @Override
	    public boolean isDealerExists(int userId, int dealerId) {
		 
		 	
			Dealer dealer=mongotemplate.findById(dealerId, Dealer.class,"dealer");
	        System.out.println(dealer);
	        
	        
	            if(dealer==null) {
	                return false;
	            }
	        return true;
	    }
	@Override
	public boolean deleteDealer(int userId,int dealerId)  {
		// TODO Auto-generated method stub
		//Deleting from the user database
		List<User> list=daoImpl.getAllUsers();
		System.out.println("Inside delete dealer");
		for(int i=0;i<list.size();i++) {
			System.out.println();
			if(!(list.get(i).getDealer()==null)) {
				if(list.get(i).getDealer().getDealerId()==dealerId) {
					list.get(i).setDealer(null);
				}
				
			}
			
			mongotemplate.save(list.get(i));
		}
		
		
                
         //Deleting from the dealer database    
               // List<Dealer> list=dealerDAO.getAllDealer();
		Dealer dealer=mongotemplate.findById(dealerId, Dealer.class,"dealer");
           mongotemplate.remove(dealer, "dealer");
			
		
                
//           
               
                
              return false;
		
	}
	 @Override
	    public boolean updateDealer(int userId, Dealer dealer) {
	  System.out.println("Inside dealer daoImpl");
			User user=userService.getUser(userId);
			user.setDealer(dealer);
			
			
			user.setDealer(dealer);
			mongotemplate.save(user.getDealer(), "dealer");
			mongotemplate.save(user, "user");
			
			return true;
//			r=null;
//					r.
//					user.setDealer(r);
//					mongotemplate.save(user);
//				   return true;
	       
	 }
//	@Override
//	public Dealer getAllDealer(int userId)  {
//		
//		//Dealer r= user.getDealer();
//		List<Dealer> dealer;
//		dealer=user.getDealer();
//		//finalMaintainance=user.getMaintainace();
//		//return finalMaintainance;
//		 //r= user.getDealer();
//		return dealer;
//	}
//	

	@Override
	public List<Dealer> getAllDealer(int userId) {
		List<User> list=daoImpl.getAllUsers();
		List<Dealer> dealers=new ArrayList<Dealer>();
		System.out.println(list);
		for(int i=0;i<list.size();i++) {
			
			Dealer dealer=list.get(i).getDealer();
			dealers.add(dealer);
			
			
//			dealers.add(i, list.get(i).getDealer());
			
			
				
				
				
				
			}
			System.out.println(dealers);
			
			
		
		
		
		
		
		
		return dealers;
	}

	@Override
	public List<Dealer> getAllDealer() {
		return mongotemplate.findAll(Dealer.class);
		
	}

}
