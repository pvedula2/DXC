import React, { Component } from 'react';
import ProductDisplay from './ProductDisplay';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import ProductDetails from './ProductDetails';
import ProductForm from '../components/ProductForm'
class ProductList extends Component {
    constructor(props) {
        super(props)
       const productList=props.productList;
        this.state = ({
            productID: '',
            quantity: '',
            productList : [
                {
                    productId: 1001,
                    productName: 'Watch',
                    quantityOnHand: 2000,
                    price: 10000
                },
                {
                    productId: 1002,
                    productName: 'Mouse',
                    quantityOnHand: 29,
                    price: 180000
                },
                {
                    productId: 1003,
                    productName: 'Laptop',
                    quantityOnHand: 29,
                    price: 122
                },
                {
                    productId: 10113,
                    productName: 'Presenter',
                    quantityOnHand: 29,
                    price: 122
                },
    
                {
                    productId: 111003,
                    productName: 'Marker',
                    quantityOnHand: 29,
                    price: 122
                }],
           
            errors: {
                productID: '',
                quantity: ''
            }
        })
        this.updateProduct=this.updateProduct.bind(this);
    }
    updateProduct(e){
        e.preventDefault();
        var quantity=this.state.quantity;
        var productID=this.state.productID;
        console.log('updating ' + productID)
        console.log('updating ' + quantity)
        console.log('updating ' + this.state.productList)
      var arr = this.state.productList
      for(var i=0;i<=arr.length;i++){
        if(arr[i].productId == productID)
        {
            arr[i].quantityOnHand = quantity;
            break
        }

    
      }
		
    this.setState({productList:arr})
console.log("updated successs")
    }
    
    doValidation = (e) => {
        e.preventDefault();
        console.log(e.target.value)
        //Target is whatever we clicked on

        const { name, value } = e.target;
        let errors = this.state.errors;
        switch (name) {
            case 'productID':
                   

                errors.productID = (value<0) ? 'Product ID cannot be negative' : ''
                if(value.length==0)
                {
                    errors.productID =  ((value.length==0) ? 'Product ID cannot be empty' : '')
                
                }
                break;
            case 'quantity':
                errors.quantity = (value<0) ? 'Quantity cannot be negative' :''
               if(value.length==0){
                (errors.quantity = (value.length==0) ? 'Quantity ID cannot be empty' : '')
               }
                break;
            default:
                break;
        }
        this.setState({
            errors, [name]: value
        })


    }


    render() {
      
        return (
            <div>
                {this.state.productList.map((product,i) =>
                    <Link to={`${this.props.match.url}/`+product.productName}>
                        <ProductDisplay render={({ match }) => match={match}}
                            
                            key={i}
                            product={product}
                        ></ProductDisplay>
                    </Link>

                )}
                 <Route path={`${this.props.match.path}/:productName`}
                    render={({ match }) => match={match}} 
                    component={ProductDetails} />
                 <div>
              
            
              <div className='wrapper'>
                  <div className='form-wrapper'>
                  
                      <h2>Enter Details</h2>
                      <form >
                          <div className='productID'>
                              <label htmlFor="productID" >Enter productID</label><input type="text" name="productID" onChange={this.doValidation} />
                          </div>
                          <span className="error">{this.state.errors.productID}</span>
                          <div className='quantity'>
                              <label htmlFor="quantity" >Enter quantity</label><input type="text" name="quantity" onChange={this.doValidation} />
                          </div>
                          <span className="error">{this.state.errors.quantity}</span>
                          <div className='submit'>
                              <button   onClick={this.updateProduct}>Submit</button>
                          </div>
                         
                      
  
                  
                          /</form>
                  </div>
              </div>
              </div>
                


                
                    
            </div>

        );
    }
}
export default ProductList;
