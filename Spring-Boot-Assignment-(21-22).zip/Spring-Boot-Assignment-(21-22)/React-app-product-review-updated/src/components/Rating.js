import React, { Component } from 'react';
import { Formik, Field,Form, ErrorMessage } from 'formik';
import ProductDataService from '../service/ProductDataService';

class Rating extends Component {
    constructor(props){
        super(props);
        this.state=({
            reviewId:this.props.match.params.revID,
            review:'',
            rating:'',
            productId:this.props.match.params.prodID,
            logic:true,
            block:false,
            title:"Enter Your Review"
        })
        this.onSubmit=this.onSubmit.bind(this);
        this.validateReview=this.validateReview.bind(this);
        
    }
   
    componentWillMount(){
        
            if(!(this.state.reviewId==undefined)){

                this.setState({
                    block:true,
                    title:"Edit your Review"

                })
                ProductDataService.getReview(this.state.productId,this.state.reviewID).then(
                    response=>{
                        console.log(response.data)
                       response.data.map(
                           data=>{
                               this.setState({
                                   review:data.review,
                                   rating:data.rating
                               })
                           }
                       )
                    }
                )
            }
            else{
                this.setState({
                    reviewID:''
                })
            }
           
            
        
        
        
    }
    onSubmit(value){
        console.log([value])
        console.log(this.state.reviewID)
        if(!(this.state.reviewID=='')){
            ProductDataService.updateReview(this.state.productId,value.reviewID,value).then(
                response=>{
                    this.props.history.push(`/product`)

                }
            )
      
        }
        else{console.log(value)
            ProductDataService.addReview(this.state.productId,value).then(
                response=>{
                    this.props.history.push(`/product`)
                }
            )

        }



    }
    giveRating(){

    }
    render() {
        let {reviewID,review,rating,productId}=this.state;
        
        return (<div>
            <div className='container'>
        <h2>{this.state.title}</h2>
             <Formik
            initialValues={{reviewID,review,rating}}
            enableReinitialize={true} onSubmit={this.onSubmit} validateOnChange= {false} validateOnBlur={false} validate={this.validateReview}>
                <Form>
               
               
               { this.state.logic?<fieldset className="form-group">
                          <label>Review Id</label>
                          <Field className="form-control " type="text" name="ratingID" disabled={this.state.block}  />
                      </fieldset>:''}
                      <fieldset className="form-group">
                          <label>Review </label>
                          <Field className="form-control" type="text" name="review" />
                      </fieldset>
                      <fieldset className="form-group">
                          <label>Rating</label>
                          <Field className="form-control" type="text" name="rating" />
                      </fieldset>
                      <button className="btn btn-success " type="submit">Give Rating</button>
                      </Form>
                      
                      </Formik>
                      
            </div>
            </div>
        );
    }
}

export default Rating;