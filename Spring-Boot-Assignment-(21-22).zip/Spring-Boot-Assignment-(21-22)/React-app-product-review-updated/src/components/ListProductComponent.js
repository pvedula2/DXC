import React, { Component } from 'react';
import ProductDataService from '../service/ProductDataService';


class ListProductComponent extends Component {
    constructor(props){
        super(props)
        this.refreshProduct=this.refreshProduct.bind(this)
        this.deleteButtonClick=this.deleteButtonClick.bind(this)
        this.updateProductClicked=this.updateProductClicked.bind(this);
        this.addProductClicked=this.addProductClicked.bind(this);
        this.SearchProducts=this.SearchProducts.bind(this);
        this.giveRating=this.giveRating.bind(this);
        this.deleteRating=this.deleteRating.bind(this);
        this.editReview=this.editReview.bind(this);
        this.state=({
            products:[],
            message:"",
            logic:false
        })

    }

    

    updateProductClicked(productId){
        this.props.history.push(`/productupdate/${productId}`)

    }
    addProductClicked(){
        this.props.history.push(`/productadd`)

    }
    deleteButtonClick(value){
        ProductDataService.deleteProduct(value).then(
            response =>{
                if(response.status==200){
                this.setState({
                    
                    message:`prouctId: ${value} has been deleted successfully`
                })
                 this.refreshProduct()}
                 else{
                     this.setState({
                         message:'There was some problem deleting'
                     })
                 }
            }
            
        )
        
        
    }
  
    componentWillMount(){
        
        this.refreshProduct();
      
    }
    refreshProduct(){
        ProductDataService.getAllProducts().then(
            response =>{
                
                this.setState({
                    products:response.data
                })
                // this.refreshProduct()
                console.log(this.state.products)
            }
            
            
        )
        
    }
    SearchProducts(){
        this.props.history.push(`/searchByName`)

    }
    giveRating(productId){ 
        console.log("inside give rating")
        this.setState({
        logic:true
    })
        this.props.history.push(`/Rating/${productId}`)
       

    }
    editReview(productId,ratingID){
        this.props.history.push(`/Rating/${productId}/${ratingID}`)

    }
    deleteRating(productId,ratingID){
        ProductDataService.deleteReview(productId,ratingID).then(
            response =>{
                if(response.status==200){
                this.setState({
                    
                    message:`prouctId: ${productId} with review ID: ${ratingID} has been deleted successfully`
                })
                 this.refreshProduct()}
                 else{
                     this.setState({
                         message:'There was some problem deleting'
                     })
                 }
            }
           
            
        )

    }

    render() {
        return (<div>
            <div className="container">
            <h2>My Product app</h2>
        {this.state.message && <div className="alert alert-success">{this.state.message}</div>}
  <table className="table table-striped table-dark table-hover">
  <thead>
    <tr>
      <th>productId</th>
      <th>productName</th>
      <th>quantityOnHand</th>
      <th>price</th>
      <th>Review</th>
      <th>Update Product</th>
      <th>Delete Product</th>
      <th> Give Review</th>
      
    </tr>
  </thead>
  <tbody>
      {
      this.state.products.map(product =>
    <tr key={product.productId}> 
        <td>{product.productId}</td>
      <td>{product.productName}</td>
      <td>{product.quantityOnHand}</td>
      <td>{product.price}</td>
      {<td>{product.reviewList.map(review =><div>
    <td>ID:{review.ratingID}</td>    
    <td>Review:{review.review}</td>
    <td>Rating: {review.rating}</td>
    <td><button className="btn btn-danger" onClick={()=>this.deleteRating(product.productId,review.ratingID)}>Delete</button></td>
    <td>{true?<button className="btn btn-success " onClick={()=>this.editReview(product.productId,review.ratingID)}>Edit Review</button>:''}</td>   
    </div>
      

      )}</td>}
      
      <td><button className="btn btn-warning" onClick={()=>this.updateProductClicked(product.productId)}>Update</button></td>
      <td><button className="btn btn-danger" onClick={()=>this.deleteButtonClick(product.productId)}>Delete</button></td>
      <td><button className="btn btn-success " onClick={()=>this.giveRating(product.productId)}>Write review</button></td>
   
    
      
    </tr>
      )
      }
  </tbody>
  
</table>
<button className="btn btn-success btn-block" onClick={()=>this.addProductClicked()}>ADD</button>
<button className="btn btn-success btn-block" onClick={()=>this.SearchProducts()}>SEARCH BY NAME</button>

            </div>
            </div>
        );
    }
}

export default ListProductComponent;