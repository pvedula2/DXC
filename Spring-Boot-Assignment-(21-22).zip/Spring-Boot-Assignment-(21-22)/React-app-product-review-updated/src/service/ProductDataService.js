import axios from 'axios'
const PRODUCT_AP_URL='http://localhost:8001/product';
const REVIEW_AP_URL='http://localhost:8001/product/review'
class ProductDataService
{
    getAllProducts(){
       return axios.get(`${PRODUCT_AP_URL}`);

    }
    deleteProduct(productId){
        return axios.delete(`${PRODUCT_AP_URL}/${productId}`);

    }
getProduct(productId){
        return axios.get(`${PRODUCT_AP_URL}/${productId}`);

    }
    updateProduct(product){
        return axios.put(`${PRODUCT_AP_URL}`,product);

    }
    addProduct(product){
        return axios.post(`${PRODUCT_AP_URL}`,product);

    }
    searchProductByName(productName){
        return axios.get(`${PRODUCT_AP_URL}/byName/${productName}`);
    }
    addReview(productId,review){
        console.log([review])
        
        return axios.post(`${REVIEW_AP_URL}/${productId}`,[review])
    }
    deleteReview(productId,reviewId){
        console.log("inside delete review")
        return axios.delete(`${REVIEW_AP_URL}/${productId}/${reviewId}`)
    }
    updateReview(productId,reviewId,review){
        return axios.put(`${REVIEW_AP_URL}/${productId}/${reviewId}`,[review])
    }
    getReview(productId,reviewId){
        return axios.get(`${REVIEW_AP_URL}/${productId}/${reviewId}`)
    }


}
export default new ProductDataService;