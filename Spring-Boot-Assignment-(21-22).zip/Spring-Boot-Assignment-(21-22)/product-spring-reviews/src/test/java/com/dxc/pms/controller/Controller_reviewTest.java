package com.dxc.pms.controller;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.dxc.pms.model.Product;
import com.dxc.pms.model.Review;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.test.AbstractTest;

public class Controller_reviewTest extends AbstractTest {

	@Before
	public void setUp() {
		 
	      
	}

	@Test
	public void testSaveProduct() throws Exception {
		 String uri = "/product/review";
		  Review review=new Review();
		  review.setRating(3);
		  review.setRatingID(300);
		  review.setReview("Product is Reliable");
	      String inputJson = super.mapToJson(review);
	      MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.post(uri)
	         .contentType(MediaType.APPLICATION_JSON_VALUE)
	         .content(inputJson)).andReturn();
	      
	      int status = mvcResult.getResponse().getStatus();
	      assertEquals(409, status);
	}

	@Test
	public void testGetReview() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetAllReviews() {
		fail("Not yet implemented");
	}

	@Test
	public void testDeleteReview() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdateReview() {
		fail("Not yet implemented");
	}

}
