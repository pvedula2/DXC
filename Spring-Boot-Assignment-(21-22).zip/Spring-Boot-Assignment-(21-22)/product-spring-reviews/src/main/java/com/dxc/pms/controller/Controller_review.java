package com.dxc.pms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dxc.pms.model.Product;
import com.dxc.pms.model.Review;
import com.dxc.pms.service.ProductService;
import com.dxc.pms.service.ReviewService;

@RestController
@RequestMapping("product/review")
@CrossOrigin(origins= {"http://localhost:3000","https://localhost:4200"})
public class Controller_review {
	@Autowired
	ReviewService service;
	@PostMapping("/{productId}")
	public ResponseEntity<Review> saveProduct(@RequestBody List<Review> review,@PathVariable("productId")int pId) {
		System.out.println("Saving a product is working");
		System.out.println(review);
		 service.addReview(review, pId);
		 return new ResponseEntity<Review>(HttpStatus.OK);
			
		}
	@GetMapping("/{productId}/{reviewId}")
	public ResponseEntity<List<Review>> getReview(@PathVariable("productId")int pId,@PathVariable("reviewId")int rId){
		List<Review> list=service.getReview(pId,rId);
		return new ResponseEntity<List<Review>>(list,HttpStatus.OK);
		
	}
	@GetMapping("/{productId}")
	public ResponseEntity<List<Review>> getAllReviews(@PathVariable("productId")int pId){
		List<Review> list=service.getAllReviews(pId);
		return new ResponseEntity<List<Review>>(list,HttpStatus.OK);
	}
	@DeleteMapping("/{productId}/{reviewId}")
	public ResponseEntity<Review> deleteReview(@PathVariable("productId")int pId,@PathVariable("reviewId")int rId){
		service.deleteReview(pId,rId);
		return new ResponseEntity<Review>(HttpStatus.OK);
		
	}
	@PutMapping("/{productId}/{reviewId}")
	public ResponseEntity<Review> updateReview(@RequestBody List<Review> list,@PathVariable("productId")int pId,@PathVariable("reviewId")int rId){
		service.updateReview(list,pId,rId);
		return new ResponseEntity<Review>(HttpStatus.OK);
		
	}
	

}
