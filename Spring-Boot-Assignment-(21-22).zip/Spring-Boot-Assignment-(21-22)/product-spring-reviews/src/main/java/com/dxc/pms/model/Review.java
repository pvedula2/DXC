package com.dxc.pms.model;

import org.springframework.data.annotation.Id;

public class Review {
	@Id
	private int ratingID;
	private String review;
	private int rating;
	public int getRatingID() {
		return ratingID;
	}
	public void setRatingID(int ratingID) {
		this.ratingID = ratingID;
	}
	public String getReview() {
		return review;
	}
	public void setReview(String review) {
		this.review = review;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + rating;
		result = prime * result + ratingID;
		result = prime * result + ((review == null) ? 0 : review.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Review other = (Review) obj;
		if (rating != other.rating)
			return false;
		if (ratingID != other.ratingID)
			return false;
		if (review == null) {
			if (other.review != null)
				return false;
		} else if (!review.equals(other.review))
			return false;
		return true;
	}
	public Review(int ratingID, String review, int rating) {
		super();
		this.ratingID = ratingID;
		this.review = review;
		this.rating = rating;
	}
	public Review() {
		super();
		this.ratingID = 0;
		this.review = " ";
		this.rating = 0;
	}
	@Override
	public String toString() {
		return "Review [ratingID=" + ratingID + ", review=" + review + ", rating=" + rating + "]";
	}
	
	
	
	

}
