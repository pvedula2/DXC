package com.dxc.pms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.dxc.pms.dao.ProductDao;
import com.dxc.pms.dao.ProductDaoImpl;
import com.dxc.pms.model.Product;
import com.dxc.pms.service.ProductService;
@RestController
@RequestMapping("product")
@CrossOrigin(origins= {"http://localhost:3000","https://localhost:4200"})
public class Controller_spring {
	@Autowired
	ProductService service;
	//This is for demo
//@RequestMapping("/getproduct/{productId}/orders/{orderId}")
//	public Product getProduct(@PathVariable("productId")int pId,@PathVariable("orderId")int oId) {
//	System.out.println("My path variable test 2. The product Id entered is "+pId+" Order Id entered is "+oId);
//		return service.getProduct(pId);
//	}
//	@RequestMapping("/getproduct/pp1")
//	public Product getProduct2() {
//		System.out.println("My path variable test 1 is working");
//		return service.getProduct(101);
//	}

	//Getting products
	@GetMapping("/{productId}")
	public ResponseEntity<Product> getProduct(@PathVariable("productId")int pId) {
	System.out.println("My path variable test 2. The product Id entered is "+pId);
	Product product=new Product();
	if(service.isProductExists(pId)) {
		product=service.getProduct(pId);
		return new ResponseEntity<Product>(product,HttpStatus.OK);
		
	}
	else {
		return new ResponseEntity<Product>(product, HttpStatus.NOT_FOUND);
	}
		
	}

	@DeleteMapping("/{productId}")
	public ResponseEntity<Product> deleteProduct(@PathVariable("productId")int pId) {
	System.out.println("Deleting product is working");
	
	if(service.isProductExists(pId)) {
		service.deleteProduct(pId);
		
		return new ResponseEntity<Product>(HttpStatus.OK);
		
	}
	else {
		return new ResponseEntity<Product>(HttpStatus.NOT_FOUND);
	}
		
	}
	@GetMapping
	public ResponseEntity<List<Product>> getAllProduct() {
	System.out.println("Getting all products is working");
	List<Product>list=service.getAllProducts();
		return new ResponseEntity<List<Product>>(list, HttpStatus.OK);
	}
	@PostMapping()
	public ResponseEntity<Product> saveProduct(@RequestBody Product product) {
	System.out.println("Saving a product is working");
	System.out.println(product);
	if(service.isProductExists(product.getProductId())) {
	   
		return new ResponseEntity<Product>(product,HttpStatus.CONFLICT);
	}
	else {
		service.addProduct(product);
		return new ResponseEntity<Product>(product, HttpStatus.CREATED);
		
	}
		
	}
	@PutMapping
	public ResponseEntity<Product> updateProduct(@RequestBody Product product) {
	System.out.println("Updating  product is working");
	System.out.println(product);
	if(service.isProductExists(product.getProductId())) {
		return new ResponseEntity<Product>(product, HttpStatus.OK);
	}
	else {
		return new ResponseEntity<Product>(product, HttpStatus.NOT_FOUND);
	}
	
		
	}
	

	

}
