package com.dxc.pms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dxc.pms.dao.ProductDao;
import com.dxc.pms.model.Product;
@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductDao dao;
	

	@Override
	public boolean addProduct(Product product) {
		// TODO Auto-generated method stub
		System.out.println("Inside product Service and the details are"+product);
		dao.addProduct(product);
		return false;
		

	}

	@Override
	public Product getProduct(int productId) {
		// TODO Auto-generated method stub
		return dao.getProduct(productId);
	}

	@Override
	public boolean deleteProduct(int productId) {
		// TODO Auto-generated method stub
		return dao.deleteProduct(productId);
	}

	@Override
	public boolean updateProduct(Product product) {
		// TODO Auto-generated method stub
		System.out.println("Inside product Service and the details are"+product);
		return dao.updateProduct(product);
	}

	@Override
	public boolean isProductExists(int productId) {
		// TODO Auto-generated method stub
		return dao.isProductExists(productId);
	}

	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return dao.getAllProducts();
	}

	@Override
	public List<Product> searchProductbyName(String productName) {
		// TODO Auto-generated method stub
		return dao.searchProductbyName(productName);
	}
	

}
