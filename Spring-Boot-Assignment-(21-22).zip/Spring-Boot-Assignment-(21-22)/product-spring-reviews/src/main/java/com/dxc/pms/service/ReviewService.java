package com.dxc.pms.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.dxc.pms.model.Review;

public interface ReviewService {
	public ResponseEntity<Review> addReview(List<Review> list,int pId);

	public List<Review> getReview(int pId, int rId);

	public List<Review> getAllReviews(int pId);

	public boolean deleteReview(int pId,int rId);

	public boolean updateReview(List<Review> list,int pId, int rId);

}
