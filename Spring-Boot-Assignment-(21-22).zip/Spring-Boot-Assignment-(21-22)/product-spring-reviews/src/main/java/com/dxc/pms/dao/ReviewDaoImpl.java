package com.dxc.pms.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;

import com.dxc.pms.model.Product;
import com.dxc.pms.model.Review;
@Repository
public class ReviewDaoImpl implements ReviewDao {
	@Autowired
MongoTemplate mongotemplate;
	@Autowired
ProductDaoImpl daoImpl;
	
	@Override
	public ResponseEntity<Review> addReview(List<Review> reviewList, int pId) {
		System.out.println(reviewList);
		Product product=daoImpl.getProduct(pId);
		List<Review> finalReview=product.getReviewList();
		finalReview.addAll(reviewList);
		product.setReviewList(finalReview);
		mongotemplate.save(product);
		
		
		
		
		
		return null;
	}

	public List<Review> getReview(int pId, int rId) {
		// TODO Auto-generated method stub
		Product product=daoImpl.getProduct(pId);
		List<Review> finalReview=product.getReviewList();
		List<Review> list = new ArrayList<Review>();
		
		for(int i=0;i<finalReview.size();i++) {
			if(finalReview.get(i).getRatingID()==rId) {
				
				list.add(finalReview.get(i));
				
			}
		}
		
		
		return list;
		
	}

	public List<Review> getAllReviews(int pId) {
		Product product=daoImpl.getProduct(pId);
		List<Review> finalReview;
		finalReview=product.getReviewList();
		return finalReview;
		
		
		
		
		
		
	}

	public boolean deleteReview(int pId,int rId) {
		// TODO Auto-generated method stub
		Product product=daoImpl.getProduct(pId);
		List<Review> finalReview;
		finalReview=product.getReviewList();
		for(int i=0;i<finalReview.size();i++) {
			if(finalReview.get(i).getRatingID()==rId) {
				finalReview.remove(i);
				
				
				
			}
			System.out.println(finalReview);
			product.setReviewList(finalReview);
			mongotemplate.save(product);
		}
		
		
		
		return true;
		
	}

	public boolean updateReview(List<Review> list,int pId, int rId) {
		Product product=daoImpl.getProduct(pId);
		List<Review> finalReview;
		finalReview=product.getReviewList();
		for(int i=0;i<finalReview.size();i++) {
			if(finalReview.get(i).getRatingID()==rId) {
				finalReview.remove(i);
				finalReview.addAll(list);
				
				
				
			}
			System.out.println(finalReview);
			product.setReviewList(finalReview);
			mongotemplate.save(product);
		}
		return false;
		// TODO Auto-generated method stub
		
	}

}
