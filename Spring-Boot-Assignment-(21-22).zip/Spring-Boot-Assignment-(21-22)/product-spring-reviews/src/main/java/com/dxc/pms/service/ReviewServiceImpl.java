package com.dxc.pms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.dxc.pms.dao.ReviewDaoImpl;
import com.dxc.pms.model.Review;

@Service
public class ReviewServiceImpl implements ReviewService {
	@Autowired
	ReviewDaoImpl dao;
	

	@Override
	public ResponseEntity<Review> addReview(List<Review> list, int pId) {
		// TODO Auto-generated method stub
		System.out.println("Coming inside review service");
		dao.addReview(list, pId);
		
		return null;
	}


	@Override
	public List<Review> getReview(int pId, int rId) {
		// TODO Auto-generated method stub
		return dao.getReview(pId,rId);
		
	}


	@Override
	public List<Review> getAllReviews(int pId) {
		
		return dao.getAllReviews(pId);
	}
	
	public boolean deleteReview(int pId,int rId) {
		dao.deleteReview(pId,rId);
		return true;
		
	}


	@Override
	public boolean updateReview(List<Review> list,int pId, int rId) {
		// TODO Auto-generated method stub
		dao.updateReview( list,pId,rId);
		return false;
	}

}
