package com.dxc.pms.dao;
import java.util.List;

import org.springframework.http.ResponseEntity;

import com.dxc.pms.model.Review;
public interface ReviewDao {
	
	public ResponseEntity<Review> addReview(List<Review> reviewList,int pId);
	public List<Review> getReview(int pId, int rId);
	public List<Review> getAllReviews(int pId);
	public boolean deleteReview(int pId,int rId);
	public boolean updateReview(List<Review> list,int pId, int rId);

}
