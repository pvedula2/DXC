package com.dxc.pms.dao;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;


import com.dxc.pms.model.Product;
import com.mongodb.WriteResult;
import com.mongodb.bulk.WriteRequest;
@Repository
public class ProductDaoImpl implements ProductDao {
	@Autowired
	MongoTemplate mongotemplate;

	@Override
	public boolean addProduct(Product product) {
		// TODO Auto-generated method stub
		System.out.println("Inside product Dao and the details are"+product);
		mongotemplate.save(product);
		return false;
		

	}


	@Override
	public Product getProduct(int productId) {
		
		mongotemplate.findById(productId, Product.class,"product");
		return mongotemplate.findById(productId, Product.class,"product");
	}

	@Override
	public boolean deleteProduct(int productId) {
		Product object=new Product();
		object.setProductId(productId);
		WriteResult result=mongotemplate.remove(object);
		System.out.println(result);
		int  rowsAffected=result.getN();
		if(rowsAffected==0)
		return false;
		else
			return true;
	}

	@Override
	public boolean updateProduct(Product product) {
		
		System.out.println("Inside product Dao and the details are"+product);
//		mongotemplate.save(product);
		Query query=new Query();
		query.addCriteria(Criteria.where("_id").is(product.getProductId()));
		Update update=new Update();
		update.set("productName", product.getProductName());
		update.set("quantityOnHand", product.getQuantityOnHand());
		update.set("price", product.getPrice());
		WriteResult result=mongotemplate.updateFirst(query, update, Product.class);
		int rowsAffected=result.getN();
		if(rowsAffected==0) {
			System.out.println("Couldnt update");
			return false;
			
		}
		else {
			System.out.println("Update successfull");
		return true;
		
		}
	}

	@Override
	public boolean isProductExists(int productId) {
		Product product=mongotemplate.findById(productId, Product.class, "product");
		if(product==null) {
			return false;
		}
		else
		return true;
	}

	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
//		String products="OnePlus";
//		BasicQuery basicQuery=new BasicQuery("{productName:"+products+"}");
//		List<Product> list=mongotemplate.find(basicQuery, Product.class);
//		System.out.println(list);
//		
		
		
		
		
		return mongotemplate.findAll(Product.class);
	}

	@Override
	public List<Product> searchProductbyName(String productName) {
//		BasicQuery basicQuery=new BasicQuery(query);
		Query query=new Query();
		query.addCriteria(Criteria.where("productName").is("OnePlus"));
		List<Product> list=mongotemplate.find(query, Product.class);
		System.out.println(list);
		return list;
	}

}
