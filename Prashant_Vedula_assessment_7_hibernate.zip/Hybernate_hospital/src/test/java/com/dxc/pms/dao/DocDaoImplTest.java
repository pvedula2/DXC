package com.dxc.pms.dao;

import java.util.List;

import com.dxc.pms.model.DoctorDetails;
import com.dxc.pms.model.Hospital;


import junit.framework.TestCase;

public class DocDaoImplTest extends TestCase {
	DocDaoImpl daoImpl;

	protected void setUp() throws Exception {
		super.setUp();
		daoImpl=new DocDaoImpl();
		
	}

	public void testGetDoctorInt() {
		Hospital hospitalDet=new Hospital("Random", "Random");
 DoctorDetails details=new DoctorDetails(120, "Dokka", 1990, hospitalDet);
		 
		 daoImpl.addDoctor(details);
		 DoctorDetails details2=daoImpl.getDoctor(120);
		 assertEquals(details.getDocName(), details2.getDocName());
		 
		 
		
		System.out.println("test complete for get Doctor");
		
		
	}

	public void testGetDoctorString() {
		Hospital hospitalDet=new Hospital("Raom", "Raom");
		 DoctorDetails details=new DoctorDetails(9722280, "Dokka", 1990, hospitalDet);
		 
				 
				 daoImpl.addDoctor(details);
				 List<DoctorDetails> details2=daoImpl.getDoctor("Dokka");
				 int size=0;
				 int size2=details2.size();
				 assertNotSame(size2, size);
				 
				 
				 
				
				System.out.println("test complete for get Doctor String");
				
		
	}

	public void testGetAllDoctors() {
		Hospital hospitalDet=new Hospital("Raom", "Raom");
		int size1=daoImpl.getAllDoctors().size(); 
		 DoctorDetails details=new DoctorDetails(906, "Dokka", 1990, hospitalDet);
		daoImpl.addDoctor(details);
		int size2=daoImpl.getAllDoctors().size();
		assertEquals(size1+1, size2);
	}

	public void testAddDoctor() {
		Hospital hospitalDet=new Hospital("Apolo", "Chennai");
		DoctorDetails details=new DoctorDetails(100, "Prashant", 10000000, hospitalDet);
		daoImpl.addDoctor(details);
		DoctorDetails details2=daoImpl.getDoctor(details.getDocId());
		
		assertEquals(details.getDocName(), details2.getDocName());;
	}

	public void testDeleteDoctor() {
		Hospital hospitalDet=new Hospital("Apolo", "Chennai");
		DoctorDetails details=new DoctorDetails(1023320, "Prashant", 10000000, hospitalDet);
		daoImpl.addDoctor(details);
		int size1=daoImpl.getAllDoctors().size();
		daoImpl.deleteDoctor(1023320);
		int size2=daoImpl.getAllDoctors().size();
		assertNotSame(size1, size2);
	}

	public void testUpdateDoctor() {
		Hospital hospitalDet=new Hospital("Apolo", "Chennai");
		DoctorDetails details=new DoctorDetails(220, "Prashant", 10000000, hospitalDet);
		
		daoImpl.addDoctor(details);
		DoctorDetails details2=new  DoctorDetails(220, "Dokkaaa", 100000, hospitalDet);
		daoImpl.updateDoctor(details2);
		assertNotSame(details.getDocName(), details2.getDocName());
		
	}

	public void testIsDcotorExists() {
		Hospital hospitalDet=new Hospital("Apolo", "Chennai");
		DoctorDetails details=new DoctorDetails(2290, "Prashant", 10000000, hospitalDet);
		
		daoImpl.addDoctor(details);
		boolean actual=daoImpl.isDcotorExists(2290);
		assertEquals(true, actual);
		
	}

}
