//package com.dxc.client.Hybernate_mongo_demo1;
//
//import org.hibernate.Session;
//import org.hibernate.SessionFactory;
//import org.hibernate.Transaction;
//import org.hibernate.ogm.cfg.OgmConfiguration;
//
//import com.dxc.model.Customer;
//import com.dxc.model.Employee;
//
///**
// * Hello world!
// *
// */
//public class App 
//{
//    public static void main( String[] args )
//    {
//        OgmConfiguration configuration=new OgmConfiguration();
//        configuration.configure();
//        SessionFactory factory=configuration.buildSessionFactory();
//        Session session=factory.openSession();
//        Transaction transaction=session.beginTransaction();
//        Employee employee=new Employee(1920,"Abhi","Mumbai",9);
////        Customer customer=new Customer(1, "Vedula", "Mumbai", 100000);
////        session.save(customer);
//        session.save(employee);
//        transaction.commit();
//        System.out.println("using annotation");
//        
//    }
//}
