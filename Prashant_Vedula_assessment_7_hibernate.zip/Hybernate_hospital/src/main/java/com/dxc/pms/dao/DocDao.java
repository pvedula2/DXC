package com.dxc.pms.dao;

import java.util.List;

import com.dxc.pms.model.DoctorDetails;


public interface DocDao {
	public DoctorDetails getDoctor(int docId);
	public List<DoctorDetails> getDoctor(String docName);
	public List<DoctorDetails> getAllDoctors();
	public void addDoctor(DoctorDetails details);
	public void deleteDoctor(int docId);
	public void updateDoctor(DoctorDetails details);
	public boolean isDcotorExists(int docId);

}
