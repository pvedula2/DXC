package com.dxc.pms.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Doc100")
public class DoctorDetails {
	@Id
	private int docId;
	private String docName;
	private int fees;
	private Hospital hospitalDet;
	public int getDocId() {
		return docId;
	}
	public void setDocId(int docId) {
		this.docId = docId;
	}
	public String getDocName() {
		return docName;
	}
	public void setDocName(String docName) {
		this.docName = docName;
	}
	public int getFees() {
		return fees;
	}
	public void setFees(int fees) {
		this.fees = fees;
	}
	public Hospital getHospitalDet() {
		return hospitalDet;
	}
	public void setHospitalDet(Hospital hospitalDet) {
		this.hospitalDet = hospitalDet;
	}
	
	public DoctorDetails() {
		super();
		this.docId = 1001;
		this.docName = "Vedula";
		this.fees = 100000;
		Hospital hospital=new Hospital();
		this.hospitalDet = hospital;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + docId;
		result = prime * result + ((docName == null) ? 0 : docName.hashCode());
		result = prime * result + fees;
		result = prime * result + ((hospitalDet == null) ? 0 : hospitalDet.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DoctorDetails other = (DoctorDetails) obj;
		if (docId != other.docId)
			return false;
		if (docName == null) {
			if (other.docName != null)
				return false;
		} else if (!docName.equals(other.docName))
			return false;
		if (fees != other.fees)
			return false;
		if (hospitalDet == null) {
			if (other.hospitalDet != null)
				return false;
		} else if (!hospitalDet.equals(other.hospitalDet))
			return false;
		return true;
	}
	public DoctorDetails(int docId, String docName, int fees, Hospital hospitalDet) {
		super();
		this.docId = docId;
		this.docName = docName;
		this.fees = fees;
		this.hospitalDet = hospitalDet;
	}
	@Override
	public String toString() {
		return "DoctorDetails [docId=" + docId + ", docName=" + docName + ", fees=" + fees + ", hospitalDet="
				+ hospitalDet + "]";
	}
	
	

}
