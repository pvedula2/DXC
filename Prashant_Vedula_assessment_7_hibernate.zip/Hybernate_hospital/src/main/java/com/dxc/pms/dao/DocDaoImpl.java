package com.dxc.pms.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.dxc.pms.model.DoctorDetails;

import com.dxc.pms.util.HibernateUtil;

public class DocDaoImpl implements DocDao {
	SessionFactory sf=HibernateUtil.getSessionFactory();

	@Override
	public DoctorDetails getDoctor(int docId) {
		// TODO Auto-generated method stub
		Session session=sf.openSession();
		Transaction transaction=session.beginTransaction();
		DoctorDetails details=(DoctorDetails) session.get(DoctorDetails.class, docId);
		transaction.commit();
		session.close();
		return details;
	}
	

	@Override
	public List<DoctorDetails> getDoctor(String docName) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		
		Query query = session.createQuery("from DoctorDetails d where d.docName=:docName");
		query.setString("docName", docName);
		return query.list();
	}

	@Override
	public List<DoctorDetails> getAllDoctors() {
		// TODO Auto-generated method stub
		Session session=sf.openSession();
		Query query=session.createQuery("from DoctorDetails");
		return query.list();
		
	}

	@Override
	public void addDoctor(DoctorDetails details) {
		// TODO Auto-generated method stub
		Session session=sf.openSession();
		Transaction transaction=session.beginTransaction();
		session.save(details);
		transaction.commit();
		session.close();
		System.out.println(details.getDocName()+"Saved sucessfully");
	

	}

	@Override
	public void deleteDoctor(int docId) {
		// TODO Auto-generated method stub
		Session session=sf.openSession();
		Transaction transaction=session.beginTransaction();
		DoctorDetails details=(DoctorDetails)session.get(DoctorDetails.class, docId);
		session.delete(details);
		transaction.commit();
		session.close();

	}

	@Override
	public void updateDoctor(DoctorDetails details) {
		// TODO Auto-generated method stub
		Session session=sf.openSession();
		Transaction transaction=session.beginTransaction();
		session.update(details);
		transaction.commit();
		session.close();

	}

	@Override
	public boolean isDcotorExists(int docId) {
		// TODO Auto-generated method stub
		Session session=sf.openSession();
		DoctorDetails details=(DoctorDetails) session.get(DoctorDetails.class, docId);
		if(details==null) {
			return false;
			
		}
		else
			return true;
		
		
		
	
	}

}
