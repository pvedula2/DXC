package com.dxc.pms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.dxc.pms.dao.ProductDao;
import com.dxc.pms.dao.ProductDaoImpl;
import com.dxc.pms.model.Product;
import com.dxc.pms.service.ProductService;
@RestController
@RequestMapping("product")
@CrossOrigin(origins= {"http://localhost:3000","https://localhost:4200"})
public class Controller_spring {
	@Autowired
	ProductService service;
	//This is for demo
//@RequestMapping("/getproduct/{productId}/orders/{orderId}")
//	public Product getProduct(@PathVariable("productId")int pId,@PathVariable("orderId")int oId) {
//	System.out.println("My path variable test 2. The product Id entered is "+pId+" Order Id entered is "+oId);
//		return service.getProduct(pId);
//	}
//	@RequestMapping("/getproduct/pp1")
//	public Product getProduct2() {
//		System.out.println("My path variable test 1 is working");
//		return service.getProduct(101);
//	}

	//Getting products
	@GetMapping("/{productId}")
	public Product getProduct(@PathVariable("productId")int pId) {
	System.out.println("My path variable test 2. The product Id entered is "+pId);
		return service.getProduct(pId);
	}
	
	@GetMapping("/byName/{productName}")
	public List<Product> getProductByName(@PathVariable("productName")String pName) {
	System.out.println("My path variable test 3. The product name entered is "+pName);
		return service.searchProductbyName(pName);
	}

	@DeleteMapping("/{productId}")
	public boolean deleteProduct(@PathVariable("productId")int pId) {
	System.out.println("Deleting product is working");
		return service.deleteProduct(pId);
	}
	@GetMapping
	public List<Product> getAllProduct() {
	System.out.println("Getting all products is working");
		return service.getAllProducts();
	}
	@PostMapping()
	public boolean saveProduct(@RequestBody Product product) {
	System.out.println("Saving a product is working");
	System.out.println(product);
		return service.addProduct(product);
	}
	@PutMapping
	public boolean updateProduct(@RequestBody Product product) {
	System.out.println("Updating  product is working");
	System.out.println(product);
		return service.updateProduct(product);	
	}
	

	

}
