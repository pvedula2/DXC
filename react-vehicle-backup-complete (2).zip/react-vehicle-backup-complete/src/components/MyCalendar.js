import React, { Component } from 'react';
import Calendar from 'react-calendar-pane';
import moment, { calendarFormat } from 'moment';
import date from 'react-calendar-pane';
import '../calendar.css'
import ProductService from '../service/ProductService';
import { Formik, Form,Field,ErrorMessage } from 'formik';

class MyCalendar extends React.Component {
    constructor(props){
        super(props);
        this.state={
          selectedDate:moment(),
          userID:this.props.match.params.uid,
          value:''
        }
        console.log(this.state.selectedDate.format('YYYY-MM-DD'))
        this.sendEmail=this.sendEmail.bind(this);
        this.handleChange=this.handleChange.bind(this)
      }
      handleChange(event){
        this.setState({
            value:event.target.value
        })
      }
      sendEmail(userID,value,date){
          ProductService.sendEmail(userID,value,date).then(
              response=>{
                 alert("Your Maintainance has been scheduled")
              }
          )

      }
      onSelect=(e)=>{
        this.setState({selectedDate:e})
      }
      render () {
          let {message}=this.state
        return(
            <div>
            <div className="App">
            <header className="App-header">
              <h1 className="App-title">Schedule Maintainence</h1>
            </header>
            <p> The date you've selected is: {this.state.selectedDate.format('YYYY-MM-DD')} </p>
            <Calendar date={moment("5/12/2019", "DD/MM/YYYY")} onSelect={this.onSelect} />
            <div className="container"> 
          <h1>App</h1>
         
              <div class = "col-md-4">
                 
                  <Formik
                   initialValues={{ message}}
                  enableReinitialize = "true"
                  validateOnChange={true}
                  validateOnBlur={false}
                  validate ={this.validateForm}
                  onSubmit={this.sendEmail(this.state.userID,this.state.message,this.state.selectedDate.format('YYYY-MM-DD'))}
                  
                  
                  >
                   
                      <Form>
                        <h2>Vehicle App</h2>
                     
                        
                    


                      <fieldset className="form-group">
                              <label>Enter any notes to the dealer</label>
                                 <Field className="form-control"  type="text" name="notes" placeholder="Enter Notes"></Field>
                      </fieldset>
                     
         
                        <div>
                        <button className="btn btn-success" type="submit">Schedule Maintainence</button>
                        </div> 
                      </Form>
                  </Formik>
                </div>
          </div>
         
    
          </div>
          </div>
        )
      }
}

export default MyCalendar;